@extends('layout')

@section('content')
    <div class="page-heading">
        <h3>Judul</h3>
    </div>

    <div class="page-content">
        <section class="section">

        </section>
    </div>
@endsection
