<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Edit Gabah</h3>
    </div>

    <div class="page-content">
        <section class="section">
            <div class="row">
                <div class="col-md-6 text-center">
                    <img src="<?php echo e(asset('assets/images/edit.svg')); ?>" alt="" class="w-75">
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Data Gabah</h5>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('master-data.update', ['id' => $gabah->id, 'jenis' => 'gabah'])); ?>" method="POST">
                                <?php echo method_field("PUT"); ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="jenis">Jenis gabah</label>
                                    <input type="text" id="jenis" class="form-control" name="jenis" required value="<?php echo e($gabah->jenis); ?>" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label for="harga">Harga / kg</label>
                                    <input type="text" id="harga" class="form-control" name="harga" required value="<?php echo e($gabah->harga); ?>" autocomplete="off">
                                </div>
                                <div class="clearfix">
                                    <button type="submit" class="btn btn-primary float-end">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\nota\resources\views/pages/master-gabah-edit.blade.php ENDPATH**/ ?>