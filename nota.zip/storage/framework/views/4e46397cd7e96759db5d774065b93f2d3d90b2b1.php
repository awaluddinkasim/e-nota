<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Edit Toko</h3>
    </div>

    <div class="page-content">
        <section class="section">
            <div class="row">
                <div class="col-md-6 text-center">
                    <img src="<?php echo e(asset('assets/images/edit.svg')); ?>" alt="" class="w-75">
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Data Toko</h5>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.master-data.update', ['id' => $toko->id, 'jenis' => 'toko'])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo method_field("PUT"); ?>
                                <?php echo csrf_field(); ?>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="nama">Nama Toko</label>
                                        <input type="text" id="nama" class="form-control" name="nama"
                                            placeholder="Nama Toko" autocomplete="off" required value="<?php echo e($toko->nama); ?>">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="alamat">Alamat Toko</label>
                                        <input type="text" id="alamat" class="form-control" name="alamat"
                                            placeholder="Alamat Toko" autocomplete="off" required value="<?php echo e($toko->alamat); ?>">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="kontak">Kontak</label>
                                        <input type="text" id="kontak" class="form-control" name="kontak"
                                            placeholder="Kontak" autocomplete="off" required value="<?php echo e($toko->kontak); ?>">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="kop">Kop Nota (Gambar)</label>
                                        <img src="<?php echo e(asset('files/toko/' . $toko->kop)); ?>" alt="" class="w-100 my-2">
                                        <input type="file" id="kop" class="form-control" name="kop"
                                            placeholder="Kop Nota">
                                    </div>
                                </div>
                                <div class="clearfix">
                                    <button type="submit" class="btn btn-primary float-end">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\nota\resources\views/admin/master-toko-edit.blade.php ENDPATH**/ ?>