<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Laporan</h3>
    </div>

    <div class="page-content">
        <section class="section">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 d-flex align-items-center">
                            <?php if(count($years) > 0): ?>
                                <form action="<?php echo e(route('admin.laporan.download')); ?>" method="post" class="w-100">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="bulan" class="form-label">Bulan</label>
                                        <select class="form-select" id="bulan" name="bulan" required>
                                            <?php for($bulan = 1; $bulan <= 12; $bulan++): ?>
                                                <option value="<?php echo e($bulan); ?>"><?php echo e($bulan); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tahun" class="form-label">Tahun</label>
                                        <select class="form-select" id="tahun" name="tahun" required>
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="clearfix">
                                        <button type="submit" class="btn btn-primary float-end">Download</button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <div class="mx-auto">
                                    <h5>Tidak ada nota ditemukan</h5>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 d-none d-md-block">
                            <img src="<?php echo e(asset('assets/images/laporan.svg')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\nota\resources\views/toko/laporan.blade.php ENDPATH**/ ?>