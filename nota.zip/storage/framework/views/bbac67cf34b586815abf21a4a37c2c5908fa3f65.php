<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
            border-spacing: 0;
            width: 100%;
        }

        td, th {
            border: solid 1px black;
            padding: 5px;
        }
    </style>
</head>

<body>
    <table>
        <tr>
            <th>Nomor Nota</th>
            <th>Jenis Gabah</th>
            <th>Pelanggan</th>
            <th>Total Harga</th>
            <th>Tanggal</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $daftarNota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($nota->nomor); ?></td>
                <td><?php echo e($nota->gabah->jenis); ?></td>
                <td><?php echo e($nota->customer->nama); ?></td>
                <td>Rp. <?php echo e(number_format($nota->items->sum('harga'))); ?></td>
                <td><?php echo e(Carbon\Carbon::parse($nota->created_at)->isoFormat('D MMMM YYYY')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" style="text-align: center">Tidak ada nota</td>
            </tr>
        <?php endif; ?>
    </table>
</body>

</html>
<?php /**PATH D:\Data\xampp\htdocs\nota\resources\views/pdf/laporan.blade.php ENDPATH**/ ?>