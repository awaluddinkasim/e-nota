<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Arsip Nota</h3>
    </div>

    <div class="page-content">
        <section class="section">
            <div class="card">
                <div class="card-header">
                    Daftar pelanggan
                </div>
                <div class="card-body">
                    <table class="table table-hover" id="table1">
                        <thead>
                            <tr>
                                <th>Nomor Nota</th>
                                <th>Jenis Gabah</th>
                                <th>Pelanggan</th>
                                <th>Total Harga</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $daftarNota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($nota->nomor); ?></td>
                                <td><?php echo e($nota->gabah->jenis); ?></td>
                                <td><?php echo e($nota->customer->nama); ?></td>
                                <td>Rp. <?php echo e(number_format($nota->total_harga)); ?></td>
                                <th>
                                    <button class="btn btn-primary btn-sm" onclick="document.location.href = '<?php echo e(route('admin.arsip-nota.detail')); ?>?id=<?php echo e($nota->id); ?>'">
                                        Detail
                                    </button>
                                </th>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/simple-datatables/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/simple-datatables.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/simple-datatables/umd/simple-datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/simple-datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\nota\resources\views/pages/nota.blade.php ENDPATH**/ ?>