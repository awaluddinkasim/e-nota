<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Detail Nota</h3>
    </div>

    <div class="page-content">
        <section class="section">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <button class="btn btn-primary btn-block mb-4" onclick="document.location.href='<?php echo e(route('customer.arsip-nota.download', $nota->id)); ?>'">
                                Download Nota
                            </button>

                            <table class="w-100">
                                <tr>
                                    <td>Nomor nota</td>
                                    <td>:</td>
                                    <td><?php echo e($nota->nomor); ?></td>
                                </tr>
                                <tr>
                                    <td>Jenis gabah</td>
                                    <td>:</td>
                                    <td><?php echo e($nota->gabah->jenis); ?></td>
                                </tr>
                                <tr>
                                    <td>Total harga</td>
                                    <td>:</td>
                                    <td>Rp. <?php echo e(number_format($nota->total_harga)); ?></td>
                                </tr>
                                <tr>
                                    <td>Catatan</td>
                                    <td>:</td>
                                    <td><?php echo e($nota->catatan ? $nota->catatan : '-'); ?></td>
                                </tr>
                                <tr>
                                    <td>Tanggal</td>
                                    <td>:</td>
                                    <td><?php echo e(Carbon\Carbon::parse($nota->created_at)->isoFormat('D MMMM YYYY')); ?></td>
                                </tr>
                            </table>

                            <h5 class="mt-3">Pelanggan</h5>
                            <table class="w-100">
                                <tr>
                                    <td>Nama</td>
                                    <td>:</td>
                                    <td><?php echo e($nota->customer->nama); ?></td>
                                </tr>
                                <tr>
                                    <td>Alamat</td>
                                    <td>:</td>
                                    <td><?php echo e($nota->customer->alamat); ?></td>
                                </tr>
                                <tr>
                                    <td>No. HP</td>
                                    <td>:</td>
                                    <td><?php echo e($nota->customer->no_hp); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Daftar gabah</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-hover" id="table1">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Jumlah</th>
                                        <th>Berat (kg)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $nota->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->jumlah); ?></td>
                                        <td><?php echo e($item->berat); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/simple-datatables/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/simple-datatables.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/simple-datatables/umd/simple-datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/simple-datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\nota\resources\views/toko/nota-detail.blade.php ENDPATH**/ ?>