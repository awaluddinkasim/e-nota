<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <h3>Edit Pedagang</h3>
    </div>

    <div class="page-content">
        <section class="section">
            <div class="row">
                <div class="col-md-6 text-center">
                    <img src="<?php echo e(asset('assets/images/edit.svg')); ?>" alt="" class="w-75">
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5>Data Pedagang</h5>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('pedagang.update', ['id' => $pedagang->id])); ?>" method="POST">
                                <?php echo method_field("PUT"); ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="nama">Nama lengkap</label>
                                    <input type="text" id="nama" class="form-control" name="nama" required value="<?php echo e($pedagang->nama); ?>" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input type="text" id="username" class="form-control" name="username" required value="<?php echo e($pedagang->username); ?>" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" id="password" class="form-control" name="password">
                                </div>
                                <div class="clearfix">
                                    <button type="submit" class="btn btn-primary float-end">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\xampp\htdocs\nota\resources\views/toko/pedagang-edit.blade.php ENDPATH**/ ?>